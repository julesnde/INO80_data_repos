This readme file describes the ARP8 module predicted using AfphaFold.

The structure contains 5 subunits: (A) Arp8, (B) Arp4, (C) Ies4, (D) Taf14, and (E) Act


