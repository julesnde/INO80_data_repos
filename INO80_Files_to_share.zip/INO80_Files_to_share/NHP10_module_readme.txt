This readme file describes the NHP10 module predicted using AfphaFold.

The structure contains 4 subunits: (A) Nhp10, (B) Ies1, (C) Ies3, and (D) Ies5

