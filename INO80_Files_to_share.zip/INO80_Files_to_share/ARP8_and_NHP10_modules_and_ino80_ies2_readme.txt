This readme file describes the Ino80, Ies2, and ARP8 and NHP10 modules predicted using AfphaFold.

The structure contains 10 subunits: (A) Ino80, (B) Ies2, (C) Arp8 and (D) Arp4, (E) Ies4, (F) Taf14, (G) Act, (H) Nhp10, (I) Ies1, and (J) Ies5.

Due to AlphaFold limitations (size), I did not include Ies3 in the NHP10 module; this subunit can be added through the docking, potantially guided by the XL-MS data. 

Note: I will advise to use this sub-complex of 10 subunits and dock Ies3 on it instead of using individual sub-complexes (ARP8 and NHP10) as this one agrees more with the current litterature. 

This specific complex can be used as the "core" to dock other modules such ARP5 and RVB12. This can be done by using individual modules RVB12 and ARP5, also shared here. The process will require docking only once but with four components: this core of 10 subunits, Ies3, RVB12 module, and ARP5 module.

One can get Ies3 (extract chain C) from the NHP10 complex for docking purpose, instead of the copy of Ies3 that was predicted as a stand alone, as the former better represents the complex context.
  
