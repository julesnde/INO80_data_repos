This readme file describes the Ino80, Ies2, and ARP5 module predicted using AfphaFold.

The structure contains 4 subunits: (A) Ino80, (B) Ies2, (C) Arp5 and (D) Ies6
