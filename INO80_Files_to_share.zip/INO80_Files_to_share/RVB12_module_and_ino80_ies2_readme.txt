This readme file describes the Ino80, Ies2, and RVB12 module predicted using AfphaFold.

The structure contains 4 subunits with 3 copies of Rvb1 and 3 copies of Rvb2: (A) Ino80, (B) Ies2, (C) Rvb1, (D) Rvb1, (E) Rvb1, (F) Rvb2, (G) Rvb2, and (H) Rvb2

