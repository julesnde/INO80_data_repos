This readme file describes the ARP5 module predicted using AfphaFold.

The structure contains 2 subunits: (A) Arp5 and (B) Ies6
