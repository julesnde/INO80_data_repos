This readme file describes the RVB12 module predicted using AfphaFold.

The structure contains 2 subunits where each subunit has 3 copies: (A-C) Rvb1 and (D-F) Rvb2

